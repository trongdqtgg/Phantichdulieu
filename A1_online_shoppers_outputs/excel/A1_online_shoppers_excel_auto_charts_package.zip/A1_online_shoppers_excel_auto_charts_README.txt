A1 Online Shoppers Intention - Excel Auto Charts

File Excel dựng tự động 36 biểu đồ trước tiền xử lý và 36 biểu đồ sau tiền xử lý.
Các sheet chính:
- README
- Excel_Steps
- Variable_Classification
- Summary_Before
- Summary_After
- Chart_Data_Before
- Chart_Data_After
- Before_Charts_36
- After_Charts_36
- VBA_Code_Optional

Ghi chú: ZIP đầu vào có cleaned CSV và reports. Vì không có file raw CSV gốc, dữ liệu before trong Excel được dựng từ thống kê before trong reports kết hợp phân phối dữ liệu hiện có để Excel có thể vẽ lại biểu đồ tự động.
